<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class LiveGame extends Model
{
    protected $table="live_games";

}
