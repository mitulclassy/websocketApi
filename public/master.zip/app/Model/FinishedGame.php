<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class FinishedGame extends Model
{
    protected $table="finished_games";
}
