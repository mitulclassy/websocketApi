<?php


namespace App\Logic;


class WS
{


    public function __construct()
    {
    }


}
