<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<center>
		<table>
			<form method="post" action="<?php echo e(route('index_post')); ?>" enctype="multipart/form-data">
				<input type="hidden" name="id" value="<?php echo e(($data) ? $data[0]->id : ''); ?>">
				<?php echo e(csrf_field()); ?>

				<tr>
					<td>
						Name :- 
					</td>
					<td>
						<input type="text" name="name" value="<?php echo e($data[0]->name); ?>">
					</td>
				</tr>
				<tr>
					<td>
						Adress :- 
					</td>
					<td>
						<input type="text" name="address" value="<?php echo e($data[0]->address); ?>">
					</td>
				</tr>
				<tr>
					<td>
						Website :- 
					</td>
					<td>
						<input type="text" name="web" value="<?php echo e($data[0]->web); ?>">
					</td>
				</tr>
				<tr>
					<td>
						Email :- 
					</td>
					<td>
						<input type="text" name="mail" value="<?php echo e($data[0]->mail); ?>">
					</td>
				</tr>
				<tr>
					<td><br>&nbsp &nbsp&nbsp&nbsp&nbsp&nbsp
					<input type="submit" value="submit">
					</td>
				</tr>
			</form>
		</table>
	</center>
</body>
</html><?php /**PATH F:\xamp\htdocs\mitul\master\resources\views/home1.blade.php ENDPATH**/ ?>