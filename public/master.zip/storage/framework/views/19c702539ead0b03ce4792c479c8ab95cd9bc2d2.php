<?php $__env->startSection('body'); ?>

    <?php

    $jsonData=(gettype($data)!='array')?$data:collect($data)->toJson();


    ?>
    <userpage :ms-data="<?php echo e($jsonData); ?>" />

<?php $__env->stopSection(); ?>


<?php echo $__env->make('root', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xamp\htdocs\mitul\master\resources\views/chess/userPage.blade.php ENDPATH**/ ?>