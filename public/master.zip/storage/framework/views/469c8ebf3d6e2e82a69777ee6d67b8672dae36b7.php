

<?php $__env->startSection('body'); ?>

<?php $jsonData=($data)?$data:collect([])->toJson();
?>
<invoiceform :ms-data="<?php echo e($jsonData); ?>" />

<?php $__env->stopSection(); ?>
<?php echo $__env->make('root', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xamp\htdocs\mitul\master\resources\views/invoiceForm.blade.php ENDPATH**/ ?>