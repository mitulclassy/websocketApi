<!DOCTYPE html>
<html>
<head>
	<title></title>
	<style type="text/css">
		.{
			margin: 0 auto;
			padding: 0px;
		}
		.main
		{
			height: 500px;
			width: 900px;
			background-color: white;
		}
		
	</style>
</head>
<body>
	<div class="main">
		<a href="<?php echo e(route('index')); ?>"><button >Create New company</button></a>
		<h4>Companies List </h4>
		<form method="post" action="<?php echo e(route('index_post')); ?>" enctype="multipart/form-data">
			<table border="3">
				<tr>
					<td>Sr No.</td>
					<td>Name</td>
					<td>Address</td>
					<td>Website</td>
					<td>Email</td>
					<td >Action</td>
				</tr>
				<?php if(@$data): ?>
				<?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
				<tr>
					<td><?php echo e($d->id); ?></td>
					<td><?php echo e($d->name); ?></td>
					<td><?php echo e($d->address); ?></td>
					<td><?php echo e($d->web); ?></td>
					<td><?php echo e($d->mail); ?></td>
					<td><a href="<?php echo e(route('edit',['id'=>$d->id])); ?>">Edit</a>&nbsp&nbsp&nbsp<a href="<?php echo e(route('delete',['id'=>$d->id])); ?>">Delete</a></td>
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
				<?php endif; ?>
				<?php endif; ?>
			</table>
		</form>
	</div>
</body>
</html><?php /**PATH F:\xamp\htdocs\mitul\master\resources\views/view.blade.php ENDPATH**/ ?>