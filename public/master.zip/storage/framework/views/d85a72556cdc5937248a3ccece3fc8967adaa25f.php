

<?php $__env->startSection('body'); ?>

<invoicelist />

<?php $__env->stopSection(); ?>
<?php echo $__env->make('root', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xamp\htdocs\mitul\master\resources\views/invoiceList.blade.php ENDPATH**/ ?>